export class Book{
    constructor(
        public id?: number,
        public name?: string,
        public writer?:string,
        public price?: number
    )
      {}
}