import React from 'react'
const About = function(){
    return(
        <div className='ui raised very padded text container' style={{marginTop: "3em"}}>
            <h2 className='ui header'>About Us </h2>
            <p>Hi my name is Puja Roy and I love coding with variant programming languages! Everyone should learn how to code!</p>
        </div>
    )
}
export default About
