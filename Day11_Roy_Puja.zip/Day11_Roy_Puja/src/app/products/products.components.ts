import { Component } from "@angular/core";

@Component({
        selector:'products', //selecting a <product></product>
        templateUrl: './products.components.html' //where am i going to find the selector
    }
)

export class ProductsComponent{
    
}